
Startpunkt Ihrer Wegesuche ist:

X=11
Y=15

Endpunkt Ihrer Wegesuche ist:

X=10
Y=5

Bewegungsm�glichkeiten sind immer nur oben/unten/links/rechts - nicht diagaonal!

