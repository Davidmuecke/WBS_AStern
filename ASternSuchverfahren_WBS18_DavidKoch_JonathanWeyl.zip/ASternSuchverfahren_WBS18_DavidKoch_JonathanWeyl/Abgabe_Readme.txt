Dieser Ordner enthält folgendes:

ASternSuchverfahren.jar
	- Runnable jar-File
	- enthält Source-Code (java-Files)

Dokumentation-AStern-Suchverfahren.pdf

S_012_Bild.png
	- Karte als Bild

S_012_Daten.csv
	- Karte im csv Format

S_012_Readme_Start_und_Ziel.txt
	- Start und Ziel Angaben für Suche

startASternSuchverfahren.bat
	- Batch-Datei zum einfachen Ausführen der Wegsuche

Test1_AStern.csv
	- Karte des Tests im csv Format

Test2_AStern.csv
	- Karte des Tests im csv Format